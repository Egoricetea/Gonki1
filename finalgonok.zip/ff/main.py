import sys
from PyQt5.QtMultimedia import QMediaPlayer, QMediaPlaylist, QMediaContent
from PyQt5.QtWidgets import QApplication, QMainWindow, QPushButton, QLabel, QMessageBox,QSlider
from PyQt5.QtCore import Qt, QTimer, QRect, QSize,QUrl
from PyQt5.QtGui import QPainter, QPixmap, QFont,QIcon
from PyQt5 import QtWidgets
import random
import json


class MainMenu(QMainWindow):
    def __init__(self):
        super().__init__()
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle("Главное меню")
        self.setGeometry(480, 255, 800, 500)

        self.background_label = QLabel(self)
        self.background_label.setGeometry(0, 0, 800, 500)
        self.background_label.setScaledContents(True)
        self.background_image = QPixmap("sprites/menu_background.png")
        self.background_label.setPixmap(self.background_image)

        self.play_button = QPushButton(self)
        self.play_button.setGeometry(300, 150, 200, 100)
        self.play_button.setStyleSheet("border: none;")
        self.play_button.setIcon(QIcon("sprites/button_play.png"))
        self.play_button.setIconSize(QSize(200,100))
        self.play_button.clicked.connect(self.start_game)

        self.set_button = QPushButton(self)
        self.set_button.setGeometry(300, 300, 200, 100)
        self.set_button.setStyleSheet("border: none;")
        self.set_button.setIcon(QIcon("sprites/button_rec.png"))
        self.set_button.setIconSize(QSize(200,100))
        self.set_button.clicked.connect(self.open_rec)

        self.set_button = QPushButton(self)
        self.set_button.setGeometry(300, 225, 200, 100)
        self.set_button.setStyleSheet("border: none;")
        self.set_button.setIcon(QIcon("sprites/button_set.png"))
        self.set_button.setIconSize(QSize(200,100))
        self.set_button.clicked.connect(self.open_settings)

        self.exit_button = QPushButton(self)
        self.exit_button.setGeometry(300, 375, 200, 100)
        self.exit_button.setStyleSheet("border: none;")
        self.exit_button.setIcon(QIcon("sprites/button_exit.png"))
        self.exit_button.setIconSize(QSize(200,100))
        self.exit_button.clicked.connect(self.close)

    def start_game(self):
        self.game_window = CarGame()
        self.game_window.show()
        self.close()

    def open_settings(self):
        self.settings_window = SettingsMenu()
        self.settings_window.show()
        self.close()

    def open_rec(self):
        self.rec_window = RecordsMenu()
        self.rec_window.show()
        self.close()


class SettingsMenu(QMainWindow):
    def __init__(self):
        super().__init__()
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle("Настройки")
        self.setGeometry(480, 255, 800, 500)

        self.background_label = QLabel(self)
        self.background_label.setGeometry(0, 0, 800, 500)
        self.background_label.setScaledContents(True)
        self.background_image = QPixmap("sprites/menu_background.png")
        self.background_label.setPixmap(self.background_image)

        self.str = QLabel(self)
        self.str.setGeometry(325, 100, 150, 100)
        self.str_image = QPixmap("sprites/str.png")
        self.str.setPixmap(self.str_image)

        self.volume_slider = QSlider(Qt.Horizontal, self)
        self.volume_slider.setGeometry(300, 200, 200, 50)
        self.volume_slider.setMinimum(0)
        self.volume_slider.setMaximum(100)
        self.volume_slider.setValue(50)
        self.volume_slider.setTickInterval(10)
        self.volume_slider.setTickPosition(QSlider.TicksBelow)

        self.back_button = QPushButton(self)
        self.back_button.setGeometry(300, 300, 200, 50)
        self.back_button.setFont(QFont('Times', 20))
        self.back_button.setStyleSheet("border: none;")
        self.back_button.setIcon(QIcon("sprites/button_back.png"))
        self.back_button.setIconSize(QSize(200, 50))
        self.back_button.clicked.connect(self.back_to_main_menu)

    def save_settings(self):
        settings = {
            'volume': self.volume_slider.value()
        }
        with open('settings.json', 'w') as file:
            json.dump(settings, file)

    def back_to_main_menu(self):
        self.save_settings()
        self.main_menu = MainMenu()
        self.main_menu.show()
        self.close()

class RecordsMenu(QMainWindow):
    def __init__(self):
        super().__init__()
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle("Рекорды")
        self.setGeometry(480, 255, 800, 500)

        self.background_label = QLabel(self)
        self.background_label.setGeometry(0, 0, 800, 500)
        self.background_label.setScaledContents(True)
        self.background_image = QPixmap("sprites/menu_background.png")
        self.background_label.setPixmap(self.background_image)

        self.records_label = QLabel(self)
        self.records_label.setGeometry(100, 50, 600, 350)
        self.records_label.setFont(QFont('Times', 20))
        self.records_label.setStyleSheet("color: white; background-color: rgba(0, 0, 0, 0.2);")
        self.records_label.setAlignment(Qt.AlignTop)
        self.update_records()

        self.back_button = QPushButton(self)
        self.back_button.setGeometry(300, 425, 200, 50)
        self.back_button.setFont(QFont('Times', 20))
        self.back_button.setStyleSheet("border: none;")
        self.back_button.setIcon(QIcon("sprites/button_back.png"))
        self.back_button.setIconSize(QSize(200, 50))
        self.back_button.clicked.connect(self.back_to_main_menu)

    def update_records(self):
        records = self.load_records()
        records_text = "\n".join([f"{i+1}. {record}" for i, record in enumerate(records)])
        self.records_label.setText(records_text)

    def load_records(self):
        try:
            with open("records.json", "r") as file:
                records = json.load(file)
                records = list(set(records))
                records.sort(reverse=True)
                records = records[:10]
        except (FileNotFoundError, json.JSONDecodeError):
            records = []
        return records

    def back_to_main_menu(self):
        self.main_menu.show()
        self.close()

    def back_to_main_menu(self):
        self.main_menu = MainMenu()
        self.main_menu.show()
        self.close()

class CarGame(QMainWindow):
    def __init__(self):
        super().__init__()

        self.init_ui()
        self.init_game_variables()
        self.init_images()
        self.start_timer()

        self.load_settings()  # загрузка настроек перед инициализацией музыкального проигрывателя

        # Проигрыватель музыки для игры
        self.playlist = QMediaPlaylist()
        self.playlist.addMedia(QMediaContent(QUrl.fromLocalFile("vfx/musick.mp3")))  # замените на свой путь к музыке
        self.playlist.setPlaybackMode(QMediaPlaylist.Loop)

        self.music_player = QMediaPlayer()
        self.music_player.setPlaylist(self.playlist)
        self.music_player.setVolume(self.music_volume)  # установка громкости из сохраненных настроек
        self.music_player.play()

    def load_settings(self):
        try:
            with open('settings.json', 'r') as file:
                settings = json.load(file)
                self.music_volume = settings.get('volume', 50)  # получение громкости из файла
        except FileNotFoundError:
            # если файл не найден, используем значение по умолчанию
            self.music_volume = 50

    def play_music(self):
        self.music_player.play()

    def init_ui(self):
        self.setWindowTitle("Гонки")
        self.setGeometry(480, 255, 800, 500)

        self.score_label = QtWidgets.QLabel(self)
        self.score_label.setGeometry(10, 450, 200, 30)
        self.score_label.setFont(QFont('Times', 20))
        self.score_label.setStyleSheet("color: orange;background-color: black;border: 2px solid black;"
                                       "padding: 2;")
        self.points = 0
        self.update_score_label()

    def init_game_variables(self):
        self.car_speeds = [20, random.randint(21, 28), random.randint(21, 28), random.randint(2, 4),
                           random.randint(2, 4), random.randint(2, 4)]
        self.player_speed = 6
        self.road_move = 15
        self.car_y_positions = [random.randint(-100, 70), random.randint(-500, 70), random.randint(-200, 70),
                                random.randint(-700, 20), random.randint(-500, 60), random.randint(-200, 35)]
        self.player_x = 535

        self.road_y_positions = [0, -496]

        self.puddle_x = random.randint(25, 700)
        self.puddle_y = random.randint(-1000, -200)

        self.barrier_x = random.randint(45, 700)
        self.barrier_y = random.randint(-1000, -200)

    def init_images(self):
        self.road_image = QPixmap("sprites/road3.png")
        self.car_sprites = [self.random_car_image(i) for i in range(6)]
        self.player_image = QPixmap("sprites/pl_car1.png")

        self.puddle_image = QPixmap("sprites/puddle.png")
        self.barrier_image = QPixmap("sprites/barrier.png")

    def random_car_image(self, index):
        if index < 3:
            return random.choice([QPixmap(f"sprites/car{i}.png") for i in range(1, 12)])
        else:
            return random.choice([QPixmap(f"sprites/car{i}_{i}.png") for i in range(1, 12)])

    def start_timer(self):
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.movec)
        self.timer.start(50)

        self.incrspeed_timer = QTimer(self)
        self.incrspeed_timer.timeout.connect(self.incr_speed)
        self.incrspeed_timer.start(5000)

    def incr_speed(self):
        if self.car_speeds[0] < 50:
            for i in range(6):
                self.car_speeds[i] += 1
            self.road_move += 1

        self.points += 10
        self.update_score_label()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setPen(Qt.NoPen)

        for y_pos in self.road_y_positions:
            painter.drawPixmap(0, y_pos, self.width(), self.height(), self.road_image)

        painter.drawPixmap(self.puddle_x, self.puddle_y, self.puddle_image)
        painter.drawPixmap(self.barrier_x, self.barrier_y, self.barrier_image)

        car_positions = [(95, self.car_y_positions[0]), (205, self.car_y_positions[1]), (310, self.car_y_positions[2]),
                         (535, self.car_y_positions[3]), (640, self.car_y_positions[4]), (430, self.car_y_positions[5])]

        for i, (x, y) in enumerate(car_positions):
            painter.drawPixmap(x, y, self.car_sprites[i])

        painter.drawPixmap(self.player_x, 340, self.player_image)
        painter.end()

    def movec(self):
        for i in range(6):
            self.car_y_positions[i] += self.car_speeds[i]

        for i in range(6):
            if self.car_y_positions[i] > self.height():
                self.car_y_positions[i] = random.randint(-1200, -800) if i < 3 else random.randint(-700, -70)
                self.car_sprites[i] = self.random_car_image(i)

        for i in range(2):
            self.road_y_positions[i] += self.road_move
            if self.road_y_positions[i] >= self.height():
                self.road_y_positions[i] = self.road_y_positions[i] - 993

        self.puddle_y += self.road_move
        if self.puddle_y > self.height():
            self.puddle_y = random.randint(-1000, -200)
            self.puddle_x = random.randint(25, 700)

        self.barrier_y += self.road_move
        if self.barrier_y > self.height():
            self.barrier_y = random.randint(-1000, -200)
            self.barrier_x = random.randint(45, 700)

        if self.check_collision():
            if self.player_rect.intersects(QRect(self.puddle_x, self.puddle_y, 60, 98)):
                for i in range(6):
                    self.car_speeds[i] += 1
                self.road_move += 1
            else:
                self.timer.stop()
                self.music_player.stop()
                QMessageBox.information(self, "Провал", "Вы потерпели крах)")
                self.music_player.stop()
                self.save_score()

        self.repaint()

    def check_collision(self):
        self.player_rect = QRect(self.player_x, 340, 60, 98)
        car_rects = [QRect(x, y, 60, 98) for x, y in [(95, self.car_y_positions[0]), (205, self.car_y_positions[1]),
                                                      (310, self.car_y_positions[2]), (535, self.car_y_positions[3]),
                                                      (640, self.car_y_positions[4]), (430, self.car_y_positions[5])]]
        puddle_rect = QRect(self.puddle_x, self.puddle_y, 60, 98)
        barrier_rect = QRect(self.barrier_x, self.barrier_y, 60, 98)

        return (self.player_rect.intersects(puddle_rect) or self.player_rect.intersects(barrier_rect) or any(self.player_rect.intersects(car_rect) for car_rect in car_rects))

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Escape:
            self.close()
        elif event.key() == Qt.Key_Left:
            self.player_x -= self.player_speed
            if self.player_x < 70:
                self.timer.stop()
                self.music_player.stop()
                QMessageBox.information(self, "Провал", "Вы потерпели крах)")
                self.save_score()
        elif event.key() == Qt.Key_Right:
            self.player_x += self.player_speed
            if self.player_x > 660:
                self.timer.stop()
                self.music_player.stop()
                QMessageBox.information(self, "Провал", "Вы потерпели крах)")
                self.save_score()
        self.repaint()

    def update_score_label(self):
        self.score_label.setText(f"Очки: {self.points}")

    def save_score(self):
        try:
            with open("records.json", "r") as file:
                records = json.load(file)
        except (FileNotFoundError, json.JSONDecodeError):
            records = []

        records.append(self.points)

        with open("records.json", "w") as file:
            json.dump(records, file)
        self.main_menu = MainMenu()
        self.main_menu.show()
        self.close()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    mainWindow = MainMenu()
    mainWindow.show()
    sys.exit(app.exec_())

